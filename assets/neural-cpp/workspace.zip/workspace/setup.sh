#!/bin/sh
# The task asset is extracted by the installer. No network or toolchain setup
# is needed; this file only exists so the installer's setup path is exercised.
exit 0
