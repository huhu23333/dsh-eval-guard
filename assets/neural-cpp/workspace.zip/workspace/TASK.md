# Neural-CPP：纯 C++ 张量运算与反向传播后端

## 目标

从空目录实现一个 Linux + GCC + C++17 的 CPU 张量库，提供 DType、Tensor、视图/切片、逐元素运算、规约、矩阵乘法、自动求导和线程池。

- 不使用 Python、OpenCL、CUDA、BLAS、Eigen 或其他第三方库。
- 只允许 C++17 标准库和 GCC 扩展 `__int128`。
- 最终产物是静态库 `nn`，头文件为 `include/nn/nn.hpp`。

## 工作区

```
workspace/
  TASK.md
  CMakeLists.txt
  include/nn/nn.hpp
  src/                 # 由你创建
```

公开头文件中的声明和语义不得修改。隐藏测试会独立编译并链接 `build/libnn.a`。

## 构建

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
test -f build/libnn.a
```

隐藏测试会用 GCC 独立编译，并链接 `build/libnn.a`。所有源文件必须能被 CMake 的 `src/*.cpp` glob 收集。

## DType

支持：

| 类别 | 类型 |
|---|---|
| 浮点 | F32、F64 |
| 有符号 | I8、I16、I32、I64、I128 |
| 无符号 | U8、U16、U32、U64、U128 |
| 软件浮点 | BF16、FP8_E5M2 |
| 块量化 | MXFP4 |

编码约定：

- 小端；连续存储。
- F32/F64 为 IEEE 754。
- BF16 为 1 符号 + 8 指数 + 7 尾数。
- FP8_E5M2 为 1 符号 + 5 指数 + 2 尾数，支持 Inf/NaN。
- I128/U128 使用 GCC `__int128` / `unsigned __int128`。
- MXFP4 使用 E2M1 数值，32 个元素共享一个 E8M0 block scale，最后一维必须按 32 对齐；反量化为 `value * 2^(scale - 127)`。
- MXFP4 的 `data()` 布局：先放 `numel/2` 字节的 nibble 数据，再放 `numel/32` 字节的 E8M0 scale；`dtype_size(MXFP4)` 仍返回 1（逻辑元素大小）。
- MXFP4 的规范量化：每个 32 元素 block 令 `max_abs` 为最大绝对值，`e = floor(log2(max_abs / 4)) + 127` 并 clamp 到 `[0,254]`，scale 为 `2^(e-127)`；每个元素按到最近 E2M1 编码舍入。随机舍入在相邻两个 E2M1 编码间按距离分配概率。

`dtype_size(DType)` 返回该类型连续存储的单元素字节数；MXFP4 返回 1（nibble 打包后的逻辑约定由实现自行维护，但 Tensor 数据接口必须可工作）。

## 类型转换

```cpp
Tensor Tensor::to(DType dst, Rounding mode = Rounding::NearestEven, uint64_t seed = 0) const;
```

要求：

- 覆盖任意 DType 到任意 DType。
- 默认最近偶数舍入；TowardZero 向零截断；Stochastic 使用按距离概率分配的随机舍入。
- 浮点转整数：舍入后饱和到目标范围；NaN 转整数为 0；Inf 饱和。
- 整型窄化默认饱和；整型算术溢出按目标宽度二补码回绕。
- 可精确表示时不发生随机。
- Stochastic 必须支持 seed，同 seed 可复现；不同元素独立。
- 随机舍入统计上应无偏：大量样本的均值接近原始值。

## Tensor

`Tensor` 至少支持：

- `empty` / `from_data`
- `shape` / `dtype` / `ndim` / `numel` / `is_contiguous`
- `data()` 返回连续的原生字节，`data()` 可被隐藏测试读取。
- `to`、`view`、`reshape`、`permute`、`slice`、`contiguous`、`clone`
- `set_requires_grad`、`requires_grad`、`grad`、`backward`

视图规则：

- row-major 连续布局；strides 以元素为单位。
- `view` 只在 stride 兼容时成功，否则抛异常；`reshape` 必要时复制。
- `permute` 零拷贝，返回共享存储的视图。
- `slice(dim,start,stop,step)` 为零拷贝视图；支持负 start/stop/step，Python 风格边界。
- `contiguous()` 已连续时返回自身，否则复制。
- 所有隐藏测试读取 `data()` 前会对结果调用 `contiguous()`；实现可以自行决定何时物化。

## 基础运算

逐元素：`add/sub/mul/div`。规则：

- 两个输入必须同为该 dtype；不做隐式混合 dtype promotion。
- 支持 NumPy 广播规则，输出 shape 为广播结果。
- 输出 dtype 与输入相同。

规约：`sum/mean`，`dim < 0` 表示全部元素。

整数/低精度使用更宽的计算类型，最终转回输入 dtype；具体累加策略可自定，但结果必须正确。

## 矩阵乘法

`matmul(a,b)`：

- 2D：`(M,K) @ (K,N) -> (M,N)`。
- 高维：最后两维为矩阵，前面的 batch 维广播。
- 输入必须同 dtype，输出同 dtype。

`matmul_nd(a,b,a_batch,b_batch,a_matrix,b_matrix)`：

- `a_matrix` 与 `b_matrix` 各恰好两个维度，形如 `{M,K}`、`{K,N}`。
- 其余维度是 batch 维；`a_batch` 与 `b_batch` 长度相同，按位置广播。
- 输出 shape = 广播后的 batch shape + `{M,N}`。

## 自动求导

`Tensor::backward()` 从标量 loss 开始反向传播；`grad()` 返回梯度 Tensor。

至少支持：

- add/sub/mul/div 的反向
- 广播的反向 reduce
- sum/mean 的反向
- matmul 和 matmul_nd 的反向
- permute/reshape/view/slice/contiguous 的反向
- 多级链式调用

约束：

- 不做 in-place autograd；`requires_grad=true` 的 Tensor 不得原地修改。
- 梯度 dtype 与对应 Tensor 相同。
- 视图梯度必须通过 scatter-add 回到共享存储。

## 线程

- 库内所有并行必须使用一个共享线程池。
- `set_thread_mode(ThreadMode::Development)` 时活动 worker 最多 4；即使硬件核数更多也不能超过 4。
- `set_thread_mode(ThreadMode::Evaluation)` 或 `set_num_threads(0)` 时使用全部逻辑 CPU。
- `active_workers()` 返回当前线程池 worker 数，供测试观察。
- 小任务允许单线程；禁止 OpenMP 自行创建额外线程。

## 性能要求

- 逐元素连续路径应向量化。
- matmul 应使用分块/缓存友好的实现，并可多线程。
- 测试会统计正确性得分和 matmul 吞吐；正确性优先，速度作为单独指标。

## 评测指标

隐藏测试至少统计：

- `f32` 矩阵乘法及其反向传播：准确率、平均绝对误差、耗时。
- `i128` 矩阵乘法及其反向传播：精确匹配率、平均绝对误差、耗时。
- `MXFP4` 矩阵乘法及其反向传播：在量化容差内统计准确率、平均误差、耗时。
- 关闭随机舍入与开启随机舍入的 MXFP4 分别统计；开启时逐元素比较参考均值/标准差和候选均值/标准差，并按指定 3σ / 0.1–10× 标准差规则统计正确元素比例。

参考值由测试侧的独立标量实现先计算完成，再调用候选实现并计时；参考计算不计入候选速度。浮点比较使用容差，整数使用精确比较。

矩阵统计规模：f32、i128、MXFP4 均使用 256×256×256。确定性项目使用 4 组独立输入取平均；随机舍入项目使用 2 组独立输入，每组固定数据采样 1024 次。

## 隐藏测试

隐藏测试不在工作区中，编译时独立注入；测试数据由固定种子在测试进程内生成，不依赖外部文件。

评分：

- accuracy：隐藏正确性用例通过率。
- speed：候选 matmul 吞吐相对基准实现的比值，仅作参考。

不要修改测试、伪造结果或绕过 API。
