#!/usr/bin/env bash
set -euo pipefail
unset PYTHONPATH PYTHONHOME
export PIP_INDEX_URL="${EVAL_PIP_INDEX_URL:-https://pypi.org/simple}"
export PIP_DISABLE_PIP_VERSION_CHECK=1
unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY
GIT_PROXY="${EVAL_GIT_PROXY:-}"
PIP_PROXY="${EVAL_PIP_PROXY:-}"
if [ -n "$GIT_PROXY" ]; then
  export http_proxy="$GIT_PROXY" https_proxy="$GIT_PROXY" all_proxy="$GIT_PROXY"
  export HTTP_PROXY="$GIT_PROXY" HTTPS_PROXY="$GIT_PROXY" ALL_PROXY="$GIT_PROXY"
fi
REPO="${EVAL_CLONE_URL:-https://github.com/msiemens/tinydb}"
SHA="ed761a72c8c1e1cb24ca4dbcc089f35c5264d357"
rm -rf .repo
echo "[1/4] clone $REPO"
git clone --filter=blob:none --no-checkout "$REPO" .repo
cd .repo
echo "[2/4] checkout $SHA"
git fetch --depth 1 origin "$SHA"
git checkout -q FETCH_HEAD
unset http_proxy https_proxy all_proxy HTTP_PROXY HTTPS_PROXY ALL_PROXY
if [ -n "$PIP_PROXY" ]; then
  export http_proxy="$PIP_PROXY" https_proxy="$PIP_PROXY" all_proxy="$PIP_PROXY"
  export HTTP_PROXY="$PIP_PROXY" HTTPS_PROXY="$PIP_PROXY" ALL_PROXY="$PIP_PROXY"
fi
cd ..
shopt -s dotglob
mv .repo/* .
rmdir .repo
rm -rf tinydb
rm -rf .git
cat > pytest.ini <<'EOF'
[pytest]
addopts = --verbose
EOF
rm -f spec.pdf.bz2
echo "[3/4] create venv"
python3 -m venv .venv
echo "[4/4] install dependencies"
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q pytest pytest-cov pytest-pycodestyle pycodestyle pyyaml typing-extensions
