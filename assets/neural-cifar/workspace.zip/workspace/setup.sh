#!/bin/sh
set -eu
# The shared downloader caches under ~/.dsh/eval-guard/cache/cifar10 and uses
# an exclusive lock while downloading. EVAL_CIFAR_URL/EVAL_CIFAR_PROXY are passed by the plugin.
python3 cifar_cache.py --copy-train data
rm -f cifar_cache.py
exit 0
