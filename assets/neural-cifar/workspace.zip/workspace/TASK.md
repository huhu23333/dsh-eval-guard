# Neural-CIFAR：从零实现 C++ 训练框架并训练图像分类网络

你是一名神经网络全栈设计及优化大师。

本任务**不限时**。请在提交前尽可能多地优化网络结构、训练策略、算子实现和推理性能。速度和未知验证集上的准确率都是重要指标，最终会参与世界顶尖水平的比拼。

## 目标

从空目录实现一个纯 C++17、仅 CPU 的 FP32 神经网络训练框架：先完成算子、反向传播、优化器和 `build/nn_task`，再构造并训练 CIFAR-10 图像分类网络，最终提供 `build/train`、`build/infer` 和训练好的 `model/`。

- 不使用 Python、OpenCL、CUDA、BLAS、Eigen 或其他第三方库。
- 仅使用 C++ 标准库和 GCC。
- 所有张量数据文件为 little-endian float32 原始字节。
- 形状参数使用逗号分隔，例如 `2,3`。
- 必须完成 CIFAR-10 训练；训练集在工作区，验证集隐藏。

## 竞赛与优化要求

- 这是一场世界顶尖水平的比拼，评分分别报告隐藏验证集准确率、推理性能、原算子正确性/误差/速度；没有单一总分，权重不公开。
- 任务时间无限，请持续优化，直到你认为已经做到当前条件下最好。
- 先做最小可用算子并跑通短训练→model→infer 基线，再补全算子正确性；昂贵模型搜索必须在算子正确性过关后进行。
- 采用固定可复现的训练集内 holdout 做自测，holdout 仅用于评估，不参与训练、增强或归一化统计。最终候选用独立划分/种子复核，尽量用全部 50k 重训交付模型。
- 记录假设、唯一主变量、命令、种子、划分、准确率、耗时和结论；任何提升小于测量噪声都要复核；保留最佳可交付模型，退步立即回退。
- 开发、自测、算子基准和训练等 agent 发起的运行最多 4 个 worker。
- 你只需要把全部精力放在优化、实验和自我批判上；评测由独立数据和外部约束执行，让结果、命令和文件可复现即可。
- 4 线程平均单图推理 <=0.02s 是要求，只报告，不做 PASS/FAIL 门控。
- 完成干净构建与端到端验收并不代表应该结束；不要因为能跑就停止探索。

## 构建

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
test -x build/nn_task
```

`CMakeLists.txt` 默认从 `src/core/*.cpp` 构建 `nncore`，从 `src/nn_task.cpp`、`src/train.cpp`、`src/infer.cpp` 构建三个可执行文件；可以按需调整，但必须产出 `build/nn_task`、`build/train`、`build/infer`。

## 线程

- 开发、自测、训练等 agent 发起的运行最多 4 个 worker。
- 线程池只能由本程序创建；不能依赖 OpenMP 的额外并发。

## CLI 协议

所有输入/输出文件都是连续 row-major float32。所有数值输出也必须写为 float32。

### 逐元素

```bash
build/nn_task elementwise --op add|sub|mul|div --shape 64,256 --a A --b B --out O
```

支持广播：从尾部对齐，维度为 1 可广播。

### 矩阵乘法

```bash
build/nn_task matmul --a-shape M,K --b-shape K,N --a A --b B --out O
```

只要求 2D 输入。

### Linear

```bash
build/nn_task linear --x-shape B,IN --w-shape OUT,IN --b-shape OUT --x X --w W --bias B --out O
```

计算 `O = X @ W^T + bias`。

### 激活

```bash
build/nn_task relu --shape N --x X --out O
build/nn_task softmax --shape B,C --x X --out O
```

Softmax 沿最后一维。

### LayerNorm

```bash
build/nn_task layernorm --shape B,C --x X --gamma G --beta B --eps 1e-5 --out O
```

对最后一维归一化；gamma/beta 形状为 `C`。

### MSE

```bash
build/nn_task mse --pred-shape S --target-shape S --pred P --target T --out O
```

输出 1 个 float32，为所有元素平均平方误差。

### Conv2d

```bash
build/nn_task conv2d --x-shape N,C,H,W --w-shape O,Cg,KH,KW --b-shape O --x X --w W --bias B --stride SH,SW --padding PH,PW --dilation DH,DW --groups G --out OUT
```

标准 NCHW 卷积，`Cg = C / groups`。

### 反向传播

```bash
build/nn_task matmul-backward --a-shape M,K --b-shape K,N --a A --b B --grad G --da DA --db DB
build/nn_task linear-backward --x-shape B,IN --w-shape OUT,IN --b-shape OUT --x X --w W --grad G --dx DX --dw DW --db DB
build/nn_task relu-backward --shape N --x X --grad G --dx DX
build/nn_task layernorm-backward --shape B,C --x X --gamma G --grad G --eps 1e-5 --dx DX --dgamma DG
build/nn_task mse-backward --pred-shape S --target-shape S --pred P --target T --grad G --dp DP --dtarget DT
build/nn_task conv2d-backward --x-shape N,C,H,W --w-shape O,Cg,KH,KW --b-shape O --x X --w W --grad G --stride SH,SW --padding PH,PW --dilation DH,DW --groups G --dx DX --dw DW --db DB
```

反向传播定义为：上游梯度 `G` 对输入、权重、bias 的梯度；`G` 与 forward 输出同形状。

### 优化器

```bash
build/nn_task adamw --param P --grad G --m M --v V --lr LR --beta1 B1 --beta2 B2 --eps EPS --weight-decay WD --step T --out-param P2 --out-m M2 --out-v V2
build/nn_task sgd-momentum --param P --grad G --momentum-buffer MB --lr LR --momentum MU --out-param P2 --out-buffer MB2
```

AdamW 使用 decoupled weight decay：

```text
m_t = beta1*m + (1-beta1)*g
v_t = beta2*v + (1-beta2)*g*g
m_hat = m_t / (1-beta1^t)
v_hat = v_t / (1-beta2^t)
param = param*(1-lr*wd) - lr*m_hat/(sqrt(v_hat)+eps)
```

SGD momentum：

```text
buffer = momentum*buffer + grad
param = param - lr*buffer
```

## 评测输出

评测会调用上述命令，用 PyTorch 在相同输入/参数上计算参考值，逐项输出：

- 是否所有操作可执行
- 每个操作的最大/加权平均相对误差
- 每个操作的速度
- 所有操作的最大加权平均相对误差
- 所有操作速度的几何平均

每个操作还会单独显示是否通过该操作误差阈值。

不做完整训练；不提供统一 score；速度无论误差是否通过都会计算。

## 约束


- 不支持自定义 dtype 或随机舍入；固定 fp32。
- 评测数据在测试进程内生成，不随工作区提供。

## 数据集

工作区只提供 CIFAR-10 训练集：

```text
data/
  train_images.bin   # 50000 x 3072 uint8, row-major RGB planar
  train_labels.bin   # 50000 uint8, 0..9
```

图像布局：每张图 3072 字节，前 1024 字节 R（32×32），然后 1024 G，然后 1024 B。

工作区提供训练集；评测使用独立验证集。训练/自测划分由 agent 自行决定。

## 训练入口

```bash
build/train --data data --out model
```

训练必须从 data/ 读取训练集，结束后把模型/权重写入 model/；格式由 agent 自定，但 infer 必须能读取。

agent 可以自行增加模块、数据增强、训练策略和网络结构。

## 推理入口

```bash
build/infer --model model --images IMAGES --out PREDICTIONS --threads N
```

- IMAGES：隐藏验证图像，N × 3072 uint8。
- PREDICTIONS：N 个 uint8 类别预测，0..9。


评测会报告：

- 验证集准确率
- 推理 FPS
- 平均单图耗时

## 额外要求

- 4 线程平均单图推理时间 <= 0.02s 是要求，不作为 PASS/FAIL 门控。
- 评测前必须完成训练并留下 model/。

- 允许增加未要求的模块来提升准确率或效率。

## 原算子指标

`build/nn_task` 的命令必须保留，评测会继续逐操作输出可执行性、PASS/FAIL、加权平均相对误差和速度，并保留 all_operations_executable、max_weighted_mean_relative_error、speed_geomean。
