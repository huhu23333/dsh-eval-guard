#!/bin/sh
set -eu
chmod +x tools/sim
exit 0
