"""查看任务用时。只读，不写任何文件。

单次任务从解压出本文件的那一刻算起，最长 90 分钟；实际计时以评测守护从对话开始的时间为准。
"""
import sys
import time
from pathlib import Path

LIMIT = 90
HERE = Path(__file__).resolve().parent


def born(path):
    st = Path(path).stat()
    return getattr(st, "st_birthtime", None) or st.st_ctime


def status(now=None, start=None):
    now = time.time() if now is None else now
    start = born(HERE / "clock.py") if start is None else start
    used = max(0.0, now - start) / 60
    if used < LIMIT:
        return f"已用 {used:.1f} 分钟，距 {LIMIT} 分钟上限还有 {LIMIT - used:.1f} 分钟。实际以评测守护为准。"
    return f"已用 {used:.1f} 分钟，已到 {LIMIT} 分钟上限：请立即停止修改并提交。"


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    print(status())
