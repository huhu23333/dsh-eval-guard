"""查看本次评测用时。只读，不写任何文件。

从解压出本文件的那一刻开始计时；整个任务最多 90 分钟，到点由评测守护强制终止。
"""
import sys
import time
from pathlib import Path

LIMIT = 90  # 分钟

HERE = Path(__file__).resolve().parent


def _born(path):
    st = Path(path).stat()
    return getattr(st, "st_birthtime", None) or st.st_ctime


def status(now=None):
    now = time.time() if now is None else now
    used = max(0.0, now - _born(Path(__file__).resolve())) / 60
    left = max(0.0, LIMIT - used)
    if left > 0:
        return f"本次评测已用 {used:.1f} 分钟，距 {LIMIT} 分钟上限还有 {left:.1f} 分钟。"
    return f"本次评测已用 {used:.1f} 分钟，已到 {LIMIT} 分钟上限，请立即停止修改并提交。"


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    print(status())
