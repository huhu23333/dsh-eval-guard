# Neural-FP32：从零实现 FP32 算子与性能任务

## 目标

从空目录实现一个纯 C++17、仅 CPU 的 FP32 神经网络算子程序，构建出 `build/nn_task`。

- 不使用 Python、OpenCL、CUDA、BLAS、Eigen 或其他第三方库。
- 仅使用 C++ 标准库和 GCC。
- 所有张量数据文件为 little-endian float32 原始字节。
- 形状参数使用逗号分隔，例如 `2,3`。
- 不要求完整训练，只要求每个算子、反向传播和优化器更新的数值与性能。

## 构建

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j4
test -x build/nn_task
```

`CMakeLists.txt` 的 `src/*.cpp` 会被收集到 `nn_task` 可执行文件。

## 线程

- 开发/自测阶段最多 4 个 worker。
- 评测阶段使用全部逻辑 CPU。
- 线程池只能由本程序创建；不能依赖 OpenMP 的额外并发。

## CLI 协议

所有输入/输出文件都是连续 row-major float32。所有数值输出也必须写为 float32。

### 逐元素

```bash
build/nn_task elementwise --op add|sub|mul|div --shape 64,256 --a A --b B --out O
```

支持广播：从尾部对齐，维度为 1 可广播。（本 CLI 评测固定传入同形状输入；广播能力需自行实现与自测。）

### 矩阵乘法

```bash
build/nn_task matmul --a-shape M,K --b-shape K,N --a A --b B --out O
```

只要求 2D 输入。

### Linear

```bash
build/nn_task linear --x-shape B,IN --w-shape OUT,IN --b-shape OUT --x X --w W --bias B --out O
```

计算 `O = X @ W^T + bias`。

### 激活

```bash
build/nn_task relu --shape N --x X --out O
build/nn_task softmax --shape B,C --x X --out O
```

Softmax 沿最后一维。

### LayerNorm

```bash
build/nn_task layernorm --shape B,C --x X --gamma G --beta B --eps 1e-5 --out O
```

对最后一维归一化；gamma/beta 形状为 `C`。

### MSE

```bash
build/nn_task mse --pred-shape S --target-shape S --pred P --target T --out O
```

输出 1 个 float32，为所有元素平均平方误差。

### Conv2d

```bash
build/nn_task conv2d --x-shape N,C,H,W --w-shape O,Cg,KH,KW --b-shape O --x X --w W --bias B --stride SH,SW --padding PH,PW --dilation DH,DW --groups G --out OUT
```

标准 NCHW 卷积，`Cg = C / groups`。

### 反向传播

```bash
build/nn_task matmul-backward --a-shape M,K --b-shape K,N --a A --b B --grad G --da DA --db DB
build/nn_task linear-backward --x-shape B,IN --w-shape OUT,IN --b-shape OUT --x X --w W --grad G --dx DX --dw DW --db DB
build/nn_task relu-backward --shape N --x X --grad G --dx DX
build/nn_task layernorm-backward --shape B,C --x X --gamma G --grad G --eps 1e-5 --dx DX --dgamma DG
build/nn_task mse-backward --pred-shape S --target-shape S --pred P --target T --grad G --dp DP --dtarget DT
build/nn_task conv2d-backward --x-shape N,C,H,W --w-shape O,Cg,KH,KW --b-shape O --x X --w W --grad G --stride SH,SW --padding PH,PW --dilation DH,DW --groups G --dx DX --dw DW --db DB
```

反向传播定义为：上游梯度 `G` 对输入、权重、bias 的梯度；`G` 与 forward 输出同形状。

### 优化器

```bash
build/nn_task adamw --param P --grad G --m M --v V --lr LR --beta1 B1 --beta2 B2 --eps EPS --weight-decay WD --step T --out-param P2 --out-m M2 --out-v V2
build/nn_task sgd-momentum --param P --grad G --momentum-buffer MB --lr LR --momentum MU --out-param P2 --out-buffer MB2
```

AdamW 使用 decoupled weight decay：

```text
m_t = beta1*m + (1-beta1)*g
v_t = beta2*v + (1-beta2)*g*g
m_hat = m_t / (1-beta1^t)
v_hat = v_t / (1-beta2^t)
param = param*(1-lr*wd) - lr*m_hat/(sqrt(v_hat)+eps)
```

SGD momentum：

```text
buffer = momentum*buffer + grad
param = param - lr*buffer
```

## 评测输出

评测会调用上述命令，用 PyTorch 在相同输入/参数上计算参考值，逐项输出：

- 是否所有操作可执行
- 每个操作的最大/加权平均相对误差
- 每个操作的速度
- 所有操作的最大加权平均相对误差
- 所有操作速度的几何平均

每个操作还会单独显示是否通过该操作误差阈值。

不做完整训练；不提供统一 score；速度无论误差是否通过都会计算。

## 约束

- 不得修改输入文件；不得伪造输出。
- 不支持自定义 dtype 或随机舍入；固定 fp32。
- 评测数据在测试进程内生成，不随工作区提供。
- 单次 CLI 调用超时 60 秒，整轮算子评测超时 30 分钟。
- 评测固定使用一组形状/参数（例如 conv2d 仅 stride=1、padding=1、dilation=1、groups=1），其他组合由实现自行保证。
