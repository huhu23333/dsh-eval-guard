#!/bin/sh
# Installation only extracts this workspace; no network or toolchain setup.
exit 0
